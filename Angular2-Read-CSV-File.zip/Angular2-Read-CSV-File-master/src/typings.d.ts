declare var app: {
  environment: string;
};

declare function require(id: string): any;
